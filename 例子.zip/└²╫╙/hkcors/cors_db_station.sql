-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: cors_db
-- ------------------------------------------------------
-- Server version	5.7.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station` (
  `name` varchar(45) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `coordsys` varchar(45) DEFAULT NULL,
  `coordx` double DEFAULT NULL,
  `coordy` double DEFAULT NULL,
  `coordz` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `protocol` varchar(45) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `account` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `mountpoint` varchar(45) DEFAULT NULL,
  `format` varchar(45) DEFAULT NULL,
  `receiver` varchar(45) DEFAULT NULL,
  `antenna` varchar(45) DEFAULT NULL,
  `gpsfreq` varchar(45) DEFAULT NULL,
  `bdsfreq` varchar(45) DEFAULT NULL,
  `glofreq` varchar(45) DEFAULT NULL,
  `galfreq` varchar(45) DEFAULT NULL,
  `connect` tinyint(4) DEFAULT NULL,
  `store` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id_2` (`id`),
  UNIQUE KEY `id_3` (`id`),
  UNIQUE KEY `id_4` (`id`),
  UNIQUE KEY `id_5` (`id`),
  UNIQUE KEY `id_6` (`id`),
  UNIQUE KEY `id_7` (`id`),
  UNIQUE KEY `id_8` (`id`),
  UNIQUE KEY `id_9` (`id`),
  UNIQUE KEY `id_10` (`id`),
  UNIQUE KEY `id_11` (`id`),
  UNIQUE KEY `id_12` (`id`),
  UNIQUE KEY `id_13` (`id`),
  UNIQUE KEY `id_14` (`id`),
  UNIQUE KEY `id_15` (`id`),
  UNIQUE KEY `id_16` (`id`),
  UNIQUE KEY `id_17` (`id`),
  UNIQUE KEY `id_18` (`id`),
  UNIQUE KEY `id_19` (`id`),
  UNIQUE KEY `id_20` (`id`),
  UNIQUE KEY `id_21` (`id`),
  UNIQUE KEY `id_22` (`id`),
  UNIQUE KEY `id_23` (`id`),
  UNIQUE KEY `id_24` (`id`),
  UNIQUE KEY `id_25` (`id`),
  UNIQUE KEY `id_26` (`id`),
  UNIQUE KEY `id_27` (`id`),
  UNIQUE KEY `id_28` (`id`),
  UNIQUE KEY `id_29` (`id`),
  UNIQUE KEY `id_30` (`id`),
  UNIQUE KEY `id_31` (`id`),
  UNIQUE KEY `id_32` (`id`),
  UNIQUE KEY `id_33` (`id`),
  UNIQUE KEY `id_34` (`id`),
  UNIQUE KEY `id_35` (`id`),
  UNIQUE KEY `id_36` (`id`),
  UNIQUE KEY `id_37` (`id`),
  UNIQUE KEY `id_38` (`id`),
  UNIQUE KEY `id_39` (`id`),
  UNIQUE KEY `id_40` (`id`),
  UNIQUE KEY `id_41` (`id`),
  UNIQUE KEY `id_42` (`id`),
  UNIQUE KEY `id_43` (`id`),
  UNIQUE KEY `id_44` (`id`),
  UNIQUE KEY `id_45` (`id`),
  UNIQUE KEY `id_46` (`id`),
  UNIQUE KEY `id_47` (`id`),
  UNIQUE KEY `id_48` (`id`),
  UNIQUE KEY `id_49` (`id`),
  UNIQUE KEY `id_50` (`id`),
  UNIQUE KEY `id_51` (`id`),
  UNIQUE KEY `id_52` (`id`),
  UNIQUE KEY `id_53` (`id`),
  UNIQUE KEY `id_54` (`id`),
  UNIQUE KEY `id_55` (`id`),
  UNIQUE KEY `id_56` (`id`),
  UNIQUE KEY `id_57` (`id`),
  UNIQUE KEY `id_58` (`id`),
  UNIQUE KEY `id_59` (`id`),
  UNIQUE KEY `id_60` (`id`),
  UNIQUE KEY `id_61` (`id`),
  UNIQUE KEY `id_62` (`id`),
  UNIQUE KEY `id_63` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES ('HKCL',200,'WGS84',-2392740.9396,5397563.0493,2404757.8653,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKCL_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKKS',203,'WGS84',-2429525.8966,5377816.636,2412152.7354,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKKS_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKKT',204,'WGS84',-2405143.899,5385195.2549,2420032.544,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKKT_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKLM',201,'WGS84',-2414045.9447,5391602.3519,2396878.8893,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKLM_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKLT',205,'WGS84',-2399062.7358,5389237.843,2417327.0568,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKLT_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKMW',206,'WGS84',-2402484.1093,5395262.4383,2400726.9555,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKMW_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKNP',207,'WGS84',-2392360.2537,5400226.2534,2400094.4576,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKNP_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKOH',208,'WGS84',-2423816.8997,5386057.0931,2399883.3709,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKOH_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKPC',209,'WGS84',-2405183.0015,5392541.8294,2403645.7303,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKPC_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKSC',210,'WGS84',-2414266.9197,5386768.9868,2407460.0314,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKSC_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKSL',211,'WGS84',-2393382.4157,5393861.1745,2412592.4105,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKSL_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKSS',212,'WGS84',-2424425.1013,5377188.1768,2418617.7454,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKSS_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKST',213,'WGS84',-2417142.8718,5382345.473,2415036.9459,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKST_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKTK',202,'WGS84',-2418092.3728,5374658.3417,2430429.1904,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKTK_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0),('HKWS',214,'WGS84',-2430579.0108,5374285.6738,2418956.3331,115.89480145,-32.00388484,1371.88021576,'NRTIP','landsd-gncaster.realtime.data.gov.hk',2101,'','','HKWS_32','rtcm3.2',NULL,NULL,'2','3','2',NULL,1,0);
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-08 19:54:34
